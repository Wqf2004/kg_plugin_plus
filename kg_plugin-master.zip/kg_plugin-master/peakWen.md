# 我对这个项目的解读

## 打包

在当前目录（peakWen.md所在目录）下执行一下指令：

```bash
npx webpack

```

1. webpack 工具自动找 webpack.config.js
2. 读取配置里的内容：

- 入口文件（从哪里开始打包）
- 输出到哪里（打包后放进 dist）
- 怎么处理 JS、资源等
