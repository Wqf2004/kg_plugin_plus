# 如何开发该项目

## 项目开始前必读

<https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Guide/Modules>

## 将这个项目运行起

先确定本地安装有 npm 包管理器

npm -v

如果没有，通过 <https://nodejs.org/zh-cn/download/> 下载安装 Node.js（自带 npm，其实 npm 就是用Node.js写的一个命令行工具）

### 初始化package.json

npm init -y

### 运行

npm run dev

此时就可以在浏览器中访问 <http://localhost:9000/> 来查看效果，修改 dist/index.html 以及 src 下的源代码，浏览器会自动刷新页面。

原理是：webpack-dev-server 不用硬盘上 dist/ 里的打包文件，它是在内存里实时打包、实时给浏览器提供最新代码，并将这些源代码加载到 dist/index.html 中。

npm run build

构建打包后的文件到 dist/ 目录下

npm run test

打包后运行测试

## 根目录下的index.html

如果使用根目录下的测试index.html在浏览器控制台会出现下面的报错：

Uncaught SyntaxError: Cannot use import statement outside a module

这个错误是前端 ES 模块最经典的语法错误，由「浏览器把你的 JS 文件当成了普通脚本，而不是 ES 模块」导致。

错误原因 1：直接双击打开 index.html（用 file:// 协议）
因为浏览器对file://协议的 ES 模块有跨域限制。

错误原因 2：没给 script 标签加 type="module" 属性
没加type="module"，浏览器当成普通脚本，不支持import
