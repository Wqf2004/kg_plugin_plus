
import * as kg from './kg/core/graph/core.js'

(function() {
  window.kg = kg
  if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = kg
  }
})()
